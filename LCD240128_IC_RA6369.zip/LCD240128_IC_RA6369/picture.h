#ifndef __picture_H__
#define __picture_H__

unsigned char code BMP0[];   
unsigned char code BMP1[];      
unsigned char code Chinese_character[];


#endif